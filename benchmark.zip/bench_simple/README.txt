BENCHMARK v2.7 - PTCG AI Battle - PROSTA INSTRUKCJA
====================================================

1. INSTALACJA (raz):
pip install --user --break-system-packages kaggle-environments numpy

2. URUCHOMIENIE (bez Rusta - działa od razu):
cd benchmark
PYTHONPATH=$HOME/.local/lib/python3.11/site-packages:$PYTHONPATH python3 tools/benchmark_v2.py --games 20

Wynik: ~77 gier/s FFI, ~311 gier/s parallel 4c

3. URUCHOMIENIE Z RUSTEM (2-11x szybciej):
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
source $HOME/.cargo/env
cd benchmark/rust
cargo build --release --bin gauntlet_rust
mkdir -p bin && cp target/release/gauntlet_rust bin/
cd ..
PYTHONPATH=$HOME/.local/lib/python3.11/site-packages:$PYTHONPATH python3 tools/benchmark_v2.py --phase 1b --games 20 --jobs 4
# Wynik: 150 gier/s (2 rdzenie), 750 gier/s (10 rdzeni)

4. POSZCZEGOLNE FAZY:
python3 tools/benchmark_v2.py --phase 1 --games 40   # FFI
python3 tools/benchmark_v2.py --phase 1b --games 40  # Rust+Rayon lub fallback parallel FFI
python3 tools/benchmark_v2.py --phase 4 --games 12   # transformer L4 7ms L8 30ms
python3 tools/benchmark_v2.py --phase 6 --games 12   # lethal ablation

SPEEDUP:
- stary wrapper: 5 gier/s
- FFI: 77.8 gier/s = 15x szybciej
- Rust 2c: 150 gier/s = 30x vs stary, 2.25x vs FFI
- Rust 10c: 750 gier/s = 150x vs stary, 11x vs FFI

PLIKI:
- tools/benchmark_v2.py - główny benchmark v2.7
- card_index.json - baza kart do liczenia obrażeń
- agents/ - agenci testowi
- decks/ - talie
- rust/ - źródła Rust+Rayon

