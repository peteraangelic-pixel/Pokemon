# Benchmark v2.7 - prosta instrukcja

## Szybki start (2 komendy)

```bash
pip install --user --break-system-packages kaggle-environments numpy
cd benchmark
PYTHONPATH=$HOME/.local/lib/python3.11/site-packages:$PYTHONPATH python3 tools/benchmark_v2.py --games 20
```

Gotowe. Działa bez Rusta: FFI 77.8 gier/s, parallel 4c ~311 gier/s.

## Z Rustem (idealnie, 150-750 gier/s)

```bash
# 1. Zainstaluj Rust
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
source $HOME/.cargo/env

# 2. Zbuduj
cd benchmark/rust
cargo build --release --bin gauntlet_rust
mkdir -p bin && cp target/release/gauntlet_rust bin/
cd ..

# 3. Uruchom z Rayon
PYTHONPATH=$HOME/.local/lib/python3.11/site-packages:$PYTHONPATH python3 tools/benchmark_v2.py --phase 1b --games 20 --jobs 4
```

## Co mierzy

- Phase1 FFI: gry/s
- Phase1b Rust: gry/s z Rayon (150/s 2c, 750/s 10c)
- Phase4: transformer ms
- Phase6: lethal ablation -8.5pp

## Speedup

Old 5/s -> FFI 77.8/s (15x) -> Rust 150/s 2c (30x) -> Rust 750/s 10c (150x)
