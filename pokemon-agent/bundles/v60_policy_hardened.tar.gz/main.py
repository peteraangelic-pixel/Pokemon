#!/usr/bin/env python3
"""v60 hardened = v59_10k_772 fixed (embedded index + bench guard) + wall guards (bench+wall)"""
import importlib.util, os, sys
_HERE = os.path.dirname(os.path.abspath(__file__))
def _load_base():
    for cand in (
        os.path.join(_HERE, "main_policy_v59_10k_772_fixed.py"),
        os.path.join(_HERE, "main_policy_v59_10k_772_embed.py"),
        os.path.join(_HERE, "main_policy_v59_10k_772.py"),
        os.path.join(os.getcwd(), "pokemon-agent/agents/main_policy_v59_10k_772_fixed.py"),
    ):
        if os.path.exists(cand):
            spec = importlib.util.spec_from_file_location("_v60_base", cand)
            mod = importlib.util.module_from_spec(spec)
            sys.modules["_v60_base"] = mod
            spec.loader.exec_module(mod)
            return mod
    raise RuntimeError("policy base not found")
_P = _load_base()
_policy_agent = _P.agent
# _FZ will be set after first agent call, but try to get it
def _get_fz():
    return getattr(_P, "_FZ", None) or getattr(_P, "_F", None)

KYOGRE = 721
ABOMASNOW_EX = 723

def _card(cid):
    try:
        fz = _get_fz()
        if fz:
            return fz.card(cid) or {}
        return {}
    except Exception:
        return {}

def _is_basic_poke(cid):
    c = _card(cid)
    return bool(c.get("b")) and c.get("ct") == 0

def _board(obs, me):
    cur = obs.get("current") or {}
    players = cur.get("players") or []
    if me >= len(players):
        return None, []
    p = players[me] or {}
    act = (p.get("active") or [None])
    bench = [b for b in (p.get("bench") or []) if b]
    return (act[0] if act else None), bench

def agent(obs: dict):
    dec = _policy_agent(obs)
    try:
        cur = obs.get("current") or {}
        if cur.get("result") is not None:
            return dec
        me = int(cur.get("yourIndex", 0))
        opp = 1 - me
        sel = obs.get("select") or {}
        opts = sel.get("option") or []
        if not opts:
            return dec
        players = cur.get("players") or []
        if len(players) < 2:
            return dec
        my_act, my_bench = _board(obs, me)
        opp_act, _ = _board(obs, opp)
        board_n = (1 if my_act else 0) + len(my_bench)

        # G3 promotion after KO, wall ahead -> Kyogre
        if int(sel.get("type") or -1) == 1 and int(sel.get("context") or -1) == 4 and my_act is None and opp_act is not None and _card(opp_act.get("id")).get("pv"):
            bench = (players[me].get("bench") or [])
            for i, o in enumerate(opts):
                if o.get("type") == 3 and o.get("area") == 5:
                    slot = o.get("index")
                    if slot is not None and 0 <= slot < len(bench) and (bench[slot] or {}).get("id") == KYOGRE:
                        return [i]
            return dec

        if int(sel.get("type") or -1) != 0:
            return dec

        # G2 wall answer
        if opp_act is not None and my_act is not None and my_act.get("id") == ABOMASNOW_EX and _card(opp_act.get("id")).get("pv"):
            kyo_slot, kyo_e = None, 0
            for i, b in enumerate(my_bench):
                if b.get("id") == KYOGRE:
                    kyo_slot, kyo_e = i, len(b.get("energies") or [])
                    break
            if kyo_slot is not None and kyo_e < 3:
                for i, o in enumerate(opts):
                    if o.get("type") == 8 and o.get("inPlayArea") == 5 and o.get("inPlayIndex") == kyo_slot:
                        return [i]
            if kyo_slot is not None and kyo_e >= 3:
                for i, o in enumerate(opts):
                    if o.get("type") == 12:
                        return [i]
            if kyo_slot is None:
                hand = players[me].get("hand") or []
                for i, o in enumerate(opts):
                    if o.get("type") == 7:
                        idx = o.get("index")
                        if idx is not None and 0 <= idx < len(hand) and (hand[idx] or {}).get("id") == KYOGRE:
                            return [i]

        # G1 never idle on starved board
        if board_n <= 1:
            hand = players[me].get("hand") or []
            has_end_or_attack = any(o.get("type") in (13, 14) for o in opts)
            if has_end_or_attack:
                for i, o in enumerate(opts):
                    if o.get("type") == 7:
                        idx = o.get("index")
                        if idx is not None and 0 <= idx < len(hand) and _is_basic_poke((hand[idx] or {}).get("id")):
                            return [i]
        return dec
    except Exception:
        return dec
