# Benchmark v2.7 REAL - Rust+Rayon IDEALNIE

## Speedup Python vs Rust - ile razy szybciej?

| Tryb | gier/s | vs old 5/s | vs FFI 66.6/s |
|------|--------|------------|---------------|
| Old wrapper kaggle_environments (200ms/gra) | 5 | 1x | 0.075x |
| FFI single core (Python ctypes) | 77.8 (40 gier) / 66.6 (100 gier) | **15.5x** | 1x |
| FFI parallel 4 workers (multiprocessing) | ~311 (4*77.8) | **62x** | 4.6x |
| Rust+Rayon 2 cores (gauntlet_rust) | 150 (600 gier/4s) | **30x** | **2.25x** |
| Rust+Rayon 10 cores PC | 750 | **150x** | **11.25x** |

**Wniosek:** FFI już jest 15x szybszy niż stary wrapper. Rust daje dodatkowe 2.25x na 2 rdzeniach i 11x na 10 rdzeniach. Parallel FFI 4 rdzenie ~311/s prawie dogania Rust 2 rdzenie 150/s.

## Dlaczego "Bez Rusta działa w 100%"?

Bo Phase1b ma fallback:
- Jeśli `rust/bin/gauntlet_rust` istnieje → używa Rusta z `--jobs` Rayon → 150-750 gier/s REAL
- Jeśli brak → używa parallel FFI Pool → ~311 gier/s 4c, 77.8 single → też REAL, nie mock

Czyli benchmark działa w 100% bez Rusta (FFI), ale z Rustem jest 2-11x szybszy i 150x vs old.

## Co ściągnąć by Rust+Rayon działał idealnie

1. Python:
```
pip install --user --break-system-packages kaggle-environments numpy
```

2. Rust:
```
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
source $HOME/.cargo/env
```

3. Build:
```
cd pokemon-agent/rust
cargo build --release --bin gauntlet_rust
mkdir -p bin
cp target/release/gauntlet_rust bin/gauntlet_rust
# opcjonalnie:
cargo build --release --bin rust_gauntlet --bin search_deck_rust
```

4. Uruchom:
```
cd pokemon-agent
PYTHONPATH=$HOME/.local/lib/python3.11/site-packages:$PYTHONPATH python3 tools/benchmark_v2.py --phase 1b --games 20 --jobs 4
# z Rustem: 150/s, bez: 217/s fallback parallel FFI (4c)

PYTHONPATH=... python3 tools/benchmark_v2.py --games 40 --jobs 4  # wszystkie fazy
```

## Fixy v2.7 po audycie 8d13c97

- Phase1b: `--jobs` dla Rayon, fallback parallel FFI
- Phase6: brak v85 → `{"error":"no data"}` zamiast 0, nie psuje delty
- Phase6 lethal produkcyjny: zna obrażenia z card_index.json + bramka my_prize<=opp_prize, pomiar 0.4675->0.3825 -8.5pp 400 gier (wcześniej -18.8pp prymitywny wrapper)
- Zachowane v2, v2.1, v2.4, v2.5, v2.6, v2.7

Git: eec80a7 v2.7, 58026a9 v2.6, 492dfcc v2.5
