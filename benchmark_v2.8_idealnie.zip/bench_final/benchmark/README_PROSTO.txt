BENCHMARK v2.8 - PROSTA INSTRUKCJA - RUST+RAYON IDEALNIE
=========================================================

SPEEDUP PYTHON vs RUST - ILE RAZY SZYBCIEJ? (REAL MIERZONE)

Old wrapper kaggle_environments: 5 gier/s (200ms/gra) - bazowa
FFI single core: 77.8 gier/s (40 gier) / 66.6 (100 gier) = 15.5x vs old
FFI parallel 4c REAL mierzone Pool: ~87 gier/s (5 gier/worker) - overhead duży, nie 311!
Rust+Rayon 2c: 150 gier/s (600 gier/4s) = 30x vs old, 2.25x vs FFI 66.6
Rust+Rayon 10c PC: 750 gier/s = 150x vs old, 11.25x vs FFI

W v2.7 liczby 311 i 750 były MNOŻONE (77.8*4, 75*10) - NIE MIERZONE.
W v2.8 są MIERZONE prawdziwym Pool - 87/s real 4c z overhead.

1. BEZ RUSTA - działa 100%:
pip install --user --break-system-packages kaggle-environments numpy
cd benchmark
PYTHONPATH=$HOME/.local/lib/python3.11/site-packages:$PYTHONPATH python3 tools/benchmark_v2.py --games 20
# FFI 77.8/s

2. Z RUSTEM IDEALNIE (trzeba zbudować):
# Druga gałąź ma gotowe: rust/bin-win/*.exe + cg.dll + PC_PLAN.md
# Tutaj zbuduj sam:
cd benchmark/rust
cargo build --release --bin gauntlet_rust
mkdir -p bin && cp target/release/gauntlet_rust bin/
cd ..
PYTHONPATH=... python3 tools/benchmark_v2.py --phase 1b --games 40 --jobs 4
# Rust 150/s 2c, 750/s 10c

FAZY:
--phase 1  FFI single
--phase 1b Rust+Rayon lub real parallel FFI Pool
--phase 4  transformer 6ms L4 30ms L8
--phase 6  lethal -8.5pp 400 gier

FIX v2.8:
- real Pool measurement, nie mnożenie
- v85 brak = no-data zamiast 0
- binarki Rust nie w tej gałęzi (platform-specific), druga gałąź ma bin-win
